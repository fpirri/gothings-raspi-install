#!/bin/sh
#
#  startup file per contenitore node service
#
#############
#
echo
echo "base: lancio del server http principale in .../raspi-test/nodebase"
node index.js
echo "ho eseguito:  node index.js (in nodebase)"
echo "-----------------------------------------"
echo 
