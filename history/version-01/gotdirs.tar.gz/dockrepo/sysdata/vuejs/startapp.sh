#!/bin/bash
#
#  startup file per contenitore sviluppi vuejs
#
#############
#
echo
echo "lancio del server http"
node index-app.js
echo "ho eseguito:  node index-app.js"
echo "-----------------------------"
echo 