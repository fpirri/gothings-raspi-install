#!/bin/bash
#                                                                    2019-07-25
#   SAVE data FROM  ~/dockrepo/sysdata   TO  ~/sysarchive/sysdata
#
#     --> set initial data for HLITE system bootstrap
#                                                                   version 0.1
##
# ---  environment
VERSION="02"
#
EDITOR=nano
RED='\033[0;41;30m'
STD='\033[0;0;39m'

pause(){
#  continue or exit
  echo "-------------------------------------------------------------- $1/"
  read -rsp $'Press any key to continue or ^C to exit ...' -n 1 key
}

copia(){
# copia da ~/sysarchive/sysdata   a  ~/dockrepo/sysdata
  echo "copia da ~/sysarchive/sysdata/   a  ~/dockrepo/sysdata/"
#  cp -rpf ~/sysarchive/sysdata/  ~/dockrepo/sysdata/
  cp -rpf ~/dockrepo/sysdata/ ~/sysarchive/
}

echo
echo "============================ ARCHIVE from ~/dockrepo/sysdata"
echo
echo "ATTENTION !!        This will overwrite ~/sysarchive/sysdata"
echo
##    ... chiedi conferma prima di proseguire
pause
echo
######################################## per ora si copia e basta (non si cancella nulla)
#rm -Rf ~/dockrepo/sysdata/*
#echo "sysdata cleaned!"
#echo
copia
echo
#echo "Contenuto in sysdata"
#tree sysdata
echo "copia effettuata"
echo
exit
