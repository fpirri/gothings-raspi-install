#!/bin/sh
#
#  startup file per contenitore node-test
#
#############
#
echo
echo "primo test: srv2"
echo "npm ha eseguito questo script in .../raspi-test/srv2"
echo "srv2: lancio server http secondario"
node index.js
echo "ho eseguito:  node index.js in srv2"
echo "-----------------------------------"
echo 
