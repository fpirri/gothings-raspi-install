import Vue from 'vue'
import App from './App'
import router from './router'
import Vuetify from 'vuetify'
import 'vuetify/dist/vuetify.min.css'
import { store } from './store'

import firebase from 'firebase'

Vue.use(Vuetify)

firebase.initializeApp({
  apiKey: 'AIzaSyDRWTa6YmC0RTuqFkAoYAZ4dnTlG8T2yws',
  authDomain: 'vueauth-e23e8.firebaseapp.com',
  databaseURL: 'https://vueauth-e23e8.firebaseio.com',
  projectId: 'vueauth-e23e8',
  storageBucket: 'vueauth-e23e8.appspot.com',
  messagingSenderId: '1025774603441'
})

Vue.config.productionTip = false

/* eslint-disable no-new */
const unsubscribe = firebase.auth()
  .onAuthStateChanged((firebaseUser) => {
    new Vue({
      el: '#app',
      router,
      store,
      render: h => h(App),
      created () {
        if (firebaseUser) {
          store.dispatch('autoSignIn', firebaseUser)
        }
      }
    })
    unsubscribe()
  })
