// super-simple nodejs http server
//   --> mantiene attivo il contenitore
//   --> usato per gli sviluppi vue
//
var http = require('http');
var count = 0
 ;
http.createServer(function (req, res) {
  count++;
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.write('Hello world!\n\n');
  res.write('I am an http server running in backgroud in a Vuejs container\n');
  res.write('I demonstrate that the container is really running\n\n');
  res.write('I am also able to count!\n');
  res.write('I counted up to '+count+'\n\n');
  res.write('I like to be called. Please call me again!');
  res.end();
}).listen(3000, "0.0.0.0");
console.log('Server now running.');
