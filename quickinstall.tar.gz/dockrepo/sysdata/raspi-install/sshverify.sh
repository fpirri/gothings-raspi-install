#!/usr/bin/expect
                                                              set Version "0.09"
#
#  Mettere gli argomenti PRIMA di pubblicare
#
#
#
set User [lindex $argv 0]
set Host [lindex $argv 1]
set Pwd [lindex $argv 2]
set LogFile [lindex $argv 3]
#
log_file "$LogFile"
set prompt "pi:"
set Red "\033\[0;41;30m"
set Std "\033\[0;0;39m"
#
set timeout  10
log_user  1
set send_slow {1 .01}
send_log  "Verify conditions to run firstboot.sh at next boot ..."
#
# costanti di lavoro:
set Prompt "pi@*$ "
set Command "/home/pi/raspi1stboot/verifyfirstboot.sh\r"
#
eval spawn ssh "$User@$Host"
set timeout  10
expect {
         timeout { send_user  "S-151: timeout  while connecting to $Host\n"; exit 151 }
         "*No route to host*" { send_user  "S-152: $Host not reachable\n"; exit 152 }
         "*assword:" { send -s "$Pwd\r" }
       }
sleep 2
set timeout  10
expect { 
         timeout  { send_user  "\nS-153: timeout after password\n"; exit 153 }
         "$prompt" {
            send -s "$Command\r"
         }
       }
sleep 2
set timeout  10
expect { 
         timeout  { send_user  "\nS-154: timeout after verify firstboot\n"; exit 154 }
         "pi:" {
            send -s "echo Result=$?\r"
         }
       }
#
#
