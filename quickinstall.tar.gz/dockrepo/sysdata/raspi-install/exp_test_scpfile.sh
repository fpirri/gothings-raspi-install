#!/bin/bash
#                                                                    2021-11-10
                                                                 Version="0.30"
                                                                        Debug=1
#
#  Test veloce di script ssh per la raspi
#
#  template da usare & ri-usare per fare prove senza dover passare
#  per tutta la trafila iniziale
#  Da riscrivere volta per volta
#
#     Vai a:                   Zona di test
#     dove inizia il test
#
##########################################################################
##########################################################################
#                                                           user functions
#
Red='\033[0;41;30m'
Std='\033[0;0;39m'
WorkDir="$HOME/dockrepo/raspi-install/"
LogDir="${WorkDir}log/"
LogFile="${LogDir}raspi-install.log"
#
redline(){
echo -e "${Red} $1 ${Std}"
}
#
pause(){
#
#  ask key before continuing (^C is active)
#    $key:  user input key
#
echo '--------------------------------------------------------------
Please, click the script STOP button to stop processing ...'
  read -rsp $'... or press the keyboard Enter key to continue ...' -n 1 key
}
#
continue(){
#  ask for user consense or stop processing
#   Y   continue
#   *   stop processing
#
  read -rsp "Do you like to Continue ? [y/N] " -n 1 key
  case "$key" in
    [yY]) 
      echo
      echo "OK, let's go on"
      echo
      ;;
    *)
      echo
      echo "It is not 'y' or 'Y', so I exit"
      exit
      ;;
  esac
}
#
dots(){
# wait $1 seconds, printing dots on the screen
#   $1 :  # of seconds to wait
  local param1
  printf -v param1 '%d\n' $1 2>/dev/null # converti in intero con tutti i controlli
  while [ $param1 -gt 0 ]
  do
    echo -n "."
    sleep 0.5
    echo -n "."
    sleep 0.5
    let "--param1"
  done
}
#
ipfilter() {
#  elimina il caso localhost (mette RaspiIp="")
#    <-- Ip == 127.0.0.1*    IP non valido
if [[ "$RaspiIp" == 127.0.0.1* ]]
then
  RaspiIp=""
  Stat=0
else
  #  RaspiIP invariato
  Stat=1
fi
}
#
# ref.: https://www.linuxjournal.com/content/validating-ip-address-bash-script
# Slightly modified to:
#     truncate trailing text
#     define & modify the var IpValid
#
# Test an IP address for validity:
# Usage:
#      valid_ip IP_ADDRESS
#   returns:
#      IpValid == <valid IP address>    if check OK
#   OR
#      IpValid == ""                    if IP address is NOT valid
#
function valid_ip()
{
    local  ip=$1
    local  stat=1
    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
            && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    if [[ $stat -eq 0 ]]
    then
      IpValid="${ip[0]}"".${ip[1]}"".${ip[2]}"".${ip[3]}"
    else
      IpValid=""
    fi
    return $stat
}
#
############################################################################
#
#  source /app/scripts/include/LocalNames.sh
#    <-- non usato sul PC
#
# avviso iniziale
echo "
------------------------------------------------------- Version: $Version\n
                                                          Debug: $Debug
Raspberry Pi quick template for expect tests"
echo
redline "Please note:"
echo '
Questa prova e' per il '\'scp\'' del dir raspi1stboot in /home/pi/
'

# verifica se expect e' installato
# parte lasciata per poter fare il test ance sul PC (no Docker)
# 
Prog=$(which expect)
Result=$?
if [ $Result -gt 0 ]
then
  echo
  redline "The 'expect' program is not installed"
  echo
  echo "I can install it on a debian OS (like Ubuntu or a raspbian) using the apt package"
  echo "Please respond y or Y so I can install it"
  echo 
  continue
  echo "Installing expect ..."
  sudo apt-get update -y
  sudo apt-get install -y expect
# verifica 'tutto OK'
  Prog=$(which expect)
  Result=$?
  if [ $Result -gt 0 ]
  then
    echo "Sorry, installation result is: $Result"
    echo "Please verify the installation process above"
    echo
    echo "You should install the expect program yourself"
    echo "You may find help searching: 'install expect package <your OS here>'"
    echo
    echo
    exit
  else
    echo "Done"
    echo
  fi
fi
echo
echo "--> $(expect -v)"
echo
#
################################################################################
#                                                                   Zona di test
################################################################################
#
#

SshUser='pi'
SshHost="192.168.1.43"
SshPwd="raspi2019"
#   LogFile  <-- vedi def all'inizio
#
echo "-------------------------------------------------- Version: $Version"
echo "                                                     Debug: $Debug"
redline "TEST: verifica scp transfer raspi1stboot da PC terminal"
echo "Go! ===================>\n"
echo
#
# live da terminale:
#   ./scpfile2raspi.sh "pi" "192.168.1.43" "raspi2019" "~/dockrepo/raspi-install/log/raspi-install.log"
#
#-----------------------------------------------------------------------
./scpfile2raspi.sh "$SshUser" "$SshHost" "$SshPwd" "$LogFile"
Result=$?
if [ $Result -gt 0 ]
then
  echo "Test x Result : $Result"
else
  echo "Test x OK"
fi
# FINE test
echo
exit

