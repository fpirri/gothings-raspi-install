#!/usr/bin/expect
                                                              set Version "1.26"
#
#  Copia un file da locale alla raspi
#
#  $1   Raspi User
#  $2   Raspi IP Address
#  $3   Raspi password
#
set User [lindex $argv 0]
set Host [lindex $argv 1]
set Pwd [lindex $argv 2]
# costanti per quickstart
set Red "\033\[0;41;30m"
set Std "\033\[0;0;39m"
set LocalDir "./scripts/raspi1stboot"

log_file /var/log/ssh_tmp.log
#send_user "$Red questo e' rosso! $Std"

send_user "Start scp script to upload 1st boot files to the raspi \n"

set timeout  10
log_user  1
set send_slow {1 .01}

send_log  "Connecting to $Host using $User User\n"
eval spawn scp -r "${LocalDir}" "$User@$Host:/boot"
expect  {
        timeout { send_user  "timeout  while connecting to $Host\n"; exit 2 }
        "*No route to host*" { send_user  "$Host not reachable\n"; exit 3 }
        "*assword: " { send -s $Pwd\r }
        }
#set timeout 20
interact

