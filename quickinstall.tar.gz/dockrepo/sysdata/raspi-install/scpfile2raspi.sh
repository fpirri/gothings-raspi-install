#!/usr/bin/expect
                                                              set Version "1.30"
#
#  Copia un file da locale alla raspi
#
#  $1   Raspi User
#  $2   Raspi IP Address
#  $3   Raspi password
#
#
#  AGGIUSTARE i parametri di chiamata
#    Mettere il possibile in environment, il resto come par di chiamata
set User [lindex $argv 0]
set Host [lindex $argv 1]
set Pwd [lindex $argv 2]
set LogFile [lindex $argv 3]
# costanti per quickstart
set Red "\033\[0;41;30m"
set Std "\033\[0;0;39m"
set LocalDir "./raspi1stboot"
#
log_file "$LogFile"
#
send_user "Start scp script to upload 1st boot files to the raspi \n"

set timeout  10
log_user  1
set send_slow {1 .01}

send_log  "Connecting to $Host using $User User\n"
eval spawn scp -r "${LocalDir}" "$User@$Host:/home/$User/"
# aggiunto errore scp:
#    scp: error while loading shared libraries: ...
expect  {
        timeout { send_user  "S-132 - timeout  while connecting to $Host\n"; exit 132 }
        "*No route to host*" { send_user  "S-133 - $Host not reachable\n"; exit 133 }
        "*error" { send_user  "S-135 - scp error \n"; exit 135 }
        "*assword: " { send -s $Pwd\r }
        }
#set timeout 20
expect eof
catch wait result
exit [lindex $result 3]

exit 0
