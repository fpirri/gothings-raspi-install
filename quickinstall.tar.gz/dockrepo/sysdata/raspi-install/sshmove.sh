#!/usr/bin/expect
                                                              set Version "1.31"
#
#  Mettere gli argomenti PRIMA di pubblicare
#
#
#
set User [lindex $argv 0]
set Host [lindex $argv 1]
set Pwd [lindex $argv 2]
set LogFile [lindex $argv 3]
#
log_file "$LogFile"
set prompt "pi:"
set Red "\033\[0;41;30m"
set Std "\033\[0;0;39m"
#
set timeout  10
log_user  1
set send_slow {1 .01}
send_log  "Move firstboot.sh to the boot partition ..."
#
eval spawn ssh "$User@$Host"
set timeout  10
expect {
         timeout { send_user  "S-141: timeout  while connecting to $Host\n"; exit 141 }
         "*No route to host*" { send_user  "S-142: $Host not reachable\n"; exit 142 }
         "*assword:" { send -s "$Pwd\r" }
       }
sleep 2
send " echo $Pwd | sudo cp /home/pi/raspi1stboot/firstboot.sh /boot/\r"
set timeout  10
expect { 
         timeout  { send_user  "\nS-143: timeout on sudo pwd\n"; exit 143 }
         "pi:" {
            send "sudo cp /home/pi/raspi1stboot/firstboot.service /lib/systemd/system/firstboot.service\r"
         }
       }
#
# ref: https://github.com/nmcclain/raspberian-firstboot#readme
#
# Il servizio firstboot e' installato nel dir:
#     
# Va anche creato il link:
#     cd /etc/systemd/system/multi-user.target.wants && ln -s /lib/systemd/system/firstboot.service .
# per abilitare effettivamente il servizio
#
# Elimina un eventuale link pre-esistente
#
sleep 2
set timeout  10
expect { 
         timeout  { send_user  "\nS-144: timeout before unlink\n"; exit 25}
         "pi:" {
            send "sudo unlink /etc/systemd/system/multi-user.target.wants/firstboot.service\r"
         }
       }
# ri-definisci il servizio
sleep 2
set timeout  10
expect { 
         timeout  { send_user  "\nS-145: timeout after unlink\n"; exit 145}
         "pi:" {
            send "cd /etc/systemd/system/multi-user.target.wants && sudo ln -s /lib/systemd/system/firstboot.service .\r"
         }
       }
sleep 2
set timeout  10
expect { 
         timeout  { send_user  "\nS-146: set link to firstboot.service\n"; exit 146}
         "pi:" { send -s "exit\r" }
       }
expect eof
catch wait result
exit [lindex $result 3]

