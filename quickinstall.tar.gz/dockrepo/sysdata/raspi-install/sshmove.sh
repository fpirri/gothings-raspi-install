#!/usr/bin/expect
                                                              set Version "1.29"
#
#  Mettere gli argomenti PRIMA di pubblicare
#
#
#
set User [lindex $argv 0]
set Host [lindex $argv 1]
set Pwd [lindex $argv 2]
set LogFile [lindex $argv 3]
#
log_file "$LogFile"
set prompt "pi:"
set Red "\033\[0;41;30m"
set Std "\033\[0;0;39m"
#
set timeout  10
log_user  1
set send_slow {1 .01}
send_log  "Move firstboot.sh to the boot partition ..."
#send -s "echo 'raspi2019' | sudo -S cp /home/pi/raspi1stboot/firstboot.sh /boot/"
#
eval spawn ssh "$User@$Host"
set timeout  10
expect {
         timeout { send_user  "timeout  while connecting to $Host\n"; exit 22 }
         "*No route to host*" { send_user  "$Host not reachable\n"; exit 23 }
         "*assword:" { send -s "$Pwd\r" }
       }
sleep 2
send " echo $Pwd | sudo cp /home/pi/raspi1stboot/firstboot.sh /boot/\r"
set timeout  10
expect { 
         timeout  { send_user  "\ntimeout on sudo pwd\n"; exit 24 }
         "pi:" {
            send "sudo cp /home/pi/raspi1stboot/firstboot.service /lib/systemd/system/firstboot.service\r"
         }
       }
#
# ref: https://github.com/nmcclain/raspberian-firstboot#readme
#
# Il servizio firstboot e' installato nel dir:
#     
# Va anche creato il link:
#     cd /etc/systemd/system/multi-user.target.wants && ln -s /lib/systemd/system/firstboot.service .
# per abilitare effettivamente il servizio
#
# Elimina un eventuale link pre-esistente
#
sleep 2
set timeout  10
expect { 
         timeout  { send_user  "\ntimeout before unlink\n"; exit 25}
         "pi:" {
            send "sudo unlink /etc/systemd/system/multi-user.target.wants/firstboot.service\r"
         }
       }
# ri-definisci il servizio
sleep 2
set timeout  10
expect { 
         timeout  { send_user  "\ntimeout after unlink\n"; exit 27}
         "pi:" {
            send "cd /etc/systemd/system/multi-user.target.wants && sudo ln -s /lib/systemd/system/firstboot.service .\r"
         }
       }
sleep 2
set timeout  10
expect { 
         timeout  { send_user  "\nset link to firstboot.service\n"; exit 28}
         "pi:" { send -s "exit" }
       }
