#!/bin/bash
#                                                                    2021-11-10
                                                                 Version="1.41"
#  Init the raspberry board to:
#    Inizializza scheda raspi con
#      OS base raspbian
#      estensione firstboot da raspberian
#        <-- credits to:   ?fare link
#      estensione script server da bugy/script server
#        <-- credits to:   ?fare link
#
#  Nota storica
#  Sviluppato su una versione docker del bugy/script-server
#
##########################################################################
##########################################################################
#                                                           user functions
#
Red='\033[0;41;30m'
Std='\033[0;0;39m'
WorkDir="$HOME/dockrepo/raspi-install/"
LogDir="${WorkDir}log/"
LogFile="${LogDir}raspi-install.log"
#
redline(){
# stampa in rosso la stringa $1
echo -e ${Red}" $1 "${Std}
}
#
pause(){
#
#  ask key before continuing (^C is active)
#    $key:  user input key
#
echo '--------------------------------------------------------------'
  read -rsp $'Press any key to continue, ^C stops processing' -n 1 key
echo
}
#
continue(){
#  ask for user consense or stop processing
#   Y   continue
#   *   stop processing
#
  read -rsp "Do you like to Continue ? [y/N] " -n 1 key
  case "$key" in
    [yY]) 
      echo
      echo "OK, let's go on"
      echo
      ;;
    *)
      echo
      echo "It is not 'y' or 'Y', so I exit"
      exit
      ;;
  esac
}
#
dots(){
# wait $1 seconds, printing dots on the screen
#   $1 :  # of seconds to wait
  local param1
  printf -v param1 '%d\n' $1 2>/dev/null # converti in intero con tutti i controlli
  while [ $param1 -gt 0 ]
  do
    echo -n "."
    sleep 0.5
    echo -n "."
    sleep 0.5
    let "--param1"
  done
}
#
#------------
log() {
#  $1   stringa da scrivere sul log file
  echo $1 >> "${LogFile}"
}
#
ipfilter() {
#  elimina il caso localhost (mette RaspiIp="")
#    <-- Ip == 127.0.0.1*    IP non valido
if [[ "$RaspiIp" == 127.0.0.1* ]]
then
  RaspiIp=""
  Stat=0
else
  #  RaspiIP invariato
  Stat=1
fi
}
#
# ref.: https://www.linuxjournal.com/content/validating-ip-address-bash-script
# Slightly modified to:
#     truncate trailing text
#     define & modify the var IpValid
#
# Test an IP address for validity:
# Usage:
#      valid_ip IP_ADDRESS
#   returns:
#      IpValid == <valid IP address>    if check OK
#   OR
#      IpValid == ""                    if IP address is NOT valid
#
function valid_ip()
{
    local  ip=$1
    local  stat=1
    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
            && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    if [[ $stat -eq 0 ]]
    then
      IpValid="${ip[0]}"".${ip[1]}"".${ip[2]}"".${ip[3]}"
    else
      IpValid=""
    fi
    return $stat
}
performtest() {
###############################
#  Perform a single test
#  In:
#      $Test                  <-- name of the test
#      $Method                <-- test to be performed
#  Out:  
#      valid IP address found -->   RaspiIp=<IP adddress>
#      no valid IP found      -->   RaspiIp=""
#  Note:
#      127.0.0.1 (localhost) is NOT considered a valid address
#
###############################
  echo
  echo "$Test"
  RaspiIp=$(eval $Method)
  valid_ip $RaspiIp
  ipfilter
  echo -n "Result: "
  if [[ "$RaspiIp" == "" ]]; then
    echo "RaspiIp KO"
  else
    echo "RaspiIp: $RaspiIp"
  fi
}
#
############################################################################
#                                                                 MAIN Logic
# verifica log dir
if [[ ! -s "$LogDir" ]]
then
  mkdir "$LogDir"
  Result=$?
  if [ $Result -gt -1 ]
  then
    echo "Error $Result while verifying log directory: ${LogDir}"
    echo "This should not happen!"
    echo "Eventually, please report to the developers"
  fi
fi
Msg="$( date '+%F_%H:%M:%S' ) Quickstart ver. $Version starts)"
### debug
echo
echo "$Msg"
echo
####
log "$Msg"
Result=$?
if [ $Result -gt 0 ]
then
  echo "Error $Result while setting working directory to ~/dockrepo/sysdata/raspi-install"
  echo "This should not happen!"
  echo "Eventually, please report to the developers"
fi

# avviso iniziale
echo '
-------------------------------------------- Raspberry Pi quick start '
echo "$Version"
redline "Please note:"
echo '
The raspi board should be powered for a few minutes before executing this
process, until it shows very low activity for at least 10 seconds.
If the board is first-time powered, time needed ranges from one minute to
several minutes. 
  (my Pi Zero with a good network connection: ~ 3 minutes)

In the following, this script will ask you several times if you like to
continue. This is useful during the beta-test now on course.
Please report to the developer if you encounter errors using this script.

Anyway, the pause may be useful to get a feeling of the script operations.

When the script ask if you like to continue, press any single key in your
keyboard to continue.
If you press ^C, that is both the ctrl key and '\'C\'', the process will STOP
'
pause
# verifica working dir
cd ~/dockrepo/sysdata/raspi-install
Result=$?
if [ $Result -gt 0 ]
then
  echo "Error $Result while setting working directory to ~/dockrepo/sysdata/raspi-install"
  echo "This should not happen!"
  echo "Eventually, please report to the developers"
fi

# verifica se expect e' installato
Prog=$(which expect)
Result=$?
if [ $Result -gt 0 ]
then
  echo
  redline "The 'expect' program is not installed"
  echo
  echo 'I can install it on a debian OS (like Ubuntu or a raspbian) using the apt package'
  echo "Please respond y or Y so I can install it"
  echo 
  continue
  echo "Installing expect ..."
  sudo apt-get update -y
  sudo apt-get install -y expect
# verifica 'tutto OK'
  Prog=$(which expect)
  Result=$?
  if [ $Result -gt 0 ]
  then
    echo "Sorry, installation result is: $Result"
    echo "Please verify the installation process above"
    echo
    echo "You should install the expect program yourself"
    echo "You may find help searching: 'install expect package <your OS here>'"
    echo
    echo
    exit
  else
    echo "Done"
    echo
  fi
fi
#
log "Quickstart initial condition OK"

#------
echo
redline "What does this script do?"
echo 'This script try to locate a new Raspberry (C) board on your LAN using
default password and hostname.
According to the documentation the board hostname is '\''raspberrypi'\'' and
the password is '\''raspberry'\''
To re-initialize a board with different parameters please look at 
<link to-be-defined> in the raspi script server documentation.
'

# 2.o avviso
redline 'The following process is not foolproof.'
echo '
Eventually, I will find the board IP address and I will test if the raspi is live and try to connect via ssh.'
pause

# Start tests

  Test="Test 1"
  Method="getent hosts raspberrypi | sed -e \"s/ .*//\""
  performtest
# *** Fine Test  ***

# TOGLIERE IN PRODUZIONE
#  # Delete test:
#  RaspiIp=""
#  echo "Delete the IP address, to cancel $Test"

Test="Test 2"
if [[ "$RaspiIp" == "" ]]
then
  Method='ping -q -c 3 -t 1 raspberrypi | grep PING | sed -e "s/).*//" | sed -e "s/.*(//"'
  performtest
fi
# *** Fine Test ***

# TOGLIERE IN PRODUZIONE
#  # Delete test:
#  RaspiIp=""
#  echo "Delete the IP address, to cancel $Test"

Test="Test 3"
if [[ "$RaspiIp" == "" ]]
then
  Method="ping -q -c 3 -t 1 raspberrypi.local | grep PING | sed -e \"s/).*//\" | sed -e \"s/.*(//\""
  performtest
fi
# *** Fine Test ***

# TOGLIERE IN PRODUZIONE
#  # Delete test:
#  RaspiIp=""
#  echo "Delete the IP address, to cancel $Test"

Test="Test 4"
if [[ "$RaspiIp" == "" ]]
then
  Method="getent hosts raspberrypi.local | sed -e \"s/ .*//\""
  performtest
fi
# *** Fine Test ***

# TOGLIERE IN PRODUZIONE
#  # Delete test:
#  RaspiIp=""
#  echo "Delete the IP address, to cancel $Test"

#
if [[ "$RaspiIp" == "" ]]
then
  Test="Test 5"
  IP='192.168.123.123'
  Method="echo $IP"
  performtest
  echo "This is a simulation, used during development only"
  echo "It give us the IP $IP which is very improbable"
  echo "The following will thus give a 'raspi not found' error"
  echo '
*** DA TOGLIERE in produzione ***
'
fi
# *** Fine Test ***
pause
#  Ora d./ovremmo avere un IP, vediamo se SSH funziona
if [[ ! "$RaspiIp" == "" ]]
then
# Abbiamo un IP ... contattiamo la scheda
#
  Test='SSH'
  # abbiamo trovato almeno un probabile IP
  # qui possiamo guardare se SSH funziona

###########!/usr/bin/expect

# variabili utili nei file expect
SshUser='pi'
SshHost="${RaspiIp}"
SshPwd="raspi2019"

# response da aggiungere:
#    yes/no
#    Network is unreachable
#
echo '
Verify raspi availability

'
redline "Start ssh call ..."
echo
./sshexpect.sh "$SshUser" "$SshHost" "$SshPwd" "$LogFile"
Result=$?
if [ $Result -gt 0 ]
then
  echo "The Raspberry (C) board is not available at address $RaspiIp"
  echo "ERROR : $Result"
######################################################  ERRORE ssh KO
################## aggiungere le varie segnalazioni ...
##################   aggiungere HELP
#####################################################################
  echo "Exiting ..."
  exit
fi
pause
echo '
Transfer boot files to the raspi board

'
./scpfile2raspi.sh "$SshUser" "$SshHost" "$SshPwd" "$LogFile"
if [ $Result -gt 0 ]
then
  echo "The file transfer to the Raspberry (C) board failed\n"
  echo "ERROR : $Result"
##################################################  ERRORE copy files
################## aggiungere le varie segnalazioni ...
##################   aggiungere HELP
#####################################################################
  echo "Exiting ..."
  exit
fi
# trasferisci firstboot
echo
redline "Set firstboot service into the boot partition"
echo
pause
echo
./sshmove.sh "$SshUser" "$SshHost" "$SshPwd" "$LogFile"
Result=$?
if [ $Result -gt 0 ]
then
  echo "Cannot set firstboot service"
  echo "ERROR : $Result"
###################################################  ERRORE firstboot
################## aggiungere le varie segnalazioni ...
##################   aggiungere HELP
#####################################################################
  echo "Exiting ..."
  exit
fi
# Verifica finale delle condizioni per firstboot
echo
redline "Verify all conditions for firstboot service execution at next boot"
echo
pause
echo
./sshverify.sh "$SshUser" "$SshHost" "$SshPwd" "$LogFile"
Result=$?
if [ $Result -gt 0 ]
then
  echo "firstboot service will NOT run at next boot"
  echo "ERROR : $Result"
###################################################  ERRORE firstboot
################## aggiungere le varie segnalazioni ...
##################   aggiungere HELP
#####################################################################
  echo "Exiting ..."
  exit
fi
echo
echo "All operation OK"

echo "****** SIAMO A POSTO !!! ********"
echo "Sono uscito !!!"
exit

####################################  ROBA DA RIGUARDARE  #####
# FINALINO DA FARE ...
echo
redline "Remote call ends ..."
echo
echo "Risultato: $Result"
#
  # 1 == va bene
  OK=1 
  # 0 == va male
  #OK=0
fi
# fine 1.o contatto con la scheda 

exit


echo
if [[ "$OK" -gt 0 ]];then
# Caso: SSH ha funzionato
 echo 'SSH e'\'' riuscito a contattare la scheda ...

***** seguito ancora da fare, ora esco ...'
  echo "e' andata bene!"
  exit ######## Uscita finale in caso positivo
else
# Caso: SSH NON ha funzionato
 echo 'SSH NON e'\'' riuscito a contattare la scheda ...
'
  echo "Sorry, non e' andata!"
  echo "Ultima prova tentata: $Test"
  echo
  echo "***** Mettiamo qui un help per il caso negativo ..."
  echo "Ho finito !!!"
fi


exit ######## uscita finale in caso negativo

### FINE
echo '
*** ROBA VARIA da controllare
# get & verify IP

The system give us the standard loopback address
The raspi is unreachable
Please verify it is still powered
It may also have a non standard name for whatever reason

*** There are are several other reason possible ! ***
You may look at the GoThings site:
  https://www.gothings.org/raspi-init-help
or google: how to find IP address Raspberry

'

