#!/bin/bash
#                                                                    2022-01-09
                                                                 Version="02.07"
#
#
################################################################################
#                                                               log script start
#  Inizializzazione della raspberry:
#    - start ssh
#    - init wifi & wpa_supplicant.conf
#    - download & start app_boot
#        <-- run_once.tar.gz: app (di gestione) da installare sulla raspberry
#        <--     run_once.sh: script di lancio di app_boot
#
#  In sostanza:
#    firstboot.sh    lavoro iniziale comune a tutti, ovvero SSH & wifi
#    app_boot        app per il lavoro 'vero', da personalizzare
#                    (abbiamo semplificato la parte comune a tutti)
#
################################################################################
#                                                     drop privileges to user pi
#  ref:  https://stackoverflow.com/a/29969243
if [ $UID -eq 0 ]; then
  cd "/home/pi"
  exec su pi "$0" -- "$@"
fi
#
################################################################################
#                                                                   init logfile
cd /home/pi
LogFile="/home/pi/firstboot.sh.log"
echo "`date` firstboot.sh ver. $Version starts" > "${LogFile}"
#
################################################################################
#                                                                 Funzioni utili
#------------
log() {
#  $1   stringa da scrivere su firstboot.sh.log
  echo $1 >> "${LogFile}"
}
#------------
errorstop() {
#  $1   codice di errore
#  $2   stringa di errore
#  $3   label chiamante (per sapere dove ...)
  if [ $1 -gt 0 ]
  then
    echo "$3 | error $1 - $2" >> "$HOME/firstboot.sh.log"
    echo "`date` firstboot.sh end" >> "$HOME/firstboot.sh.log"
    exit $1
  else
    echo "$3 | passed" >> "$HOME/firstboot.sh.log"
  fi
}
#
#---------
setdir() {
#  $1  verifica esistenza dir
#    <-- crea dir se non esiste
#    <-- exit 81 on error, ok se esiste gia'
  local Result
  Result=0
  if [[ -z "$1" ]]
  then
    errorstop "81" "setdir: empty varname"  "setdir: $1"
  else
    if [ ! -d "$1" ]
    then
      mkdir "$1"
      Result=$?
      if [[ ! $Result -eq 1 ]] # elimina dir exists error
      then
        errorstop ${Result} "set dir $1 non riuscito"  "set dir $1"
      fi
    fi
  fi
# log ok result
  errorstop ${Result} "Error on $1 dir"  "Dir $1"
}
#
################################################################################
#                                              verifica - togliere in produzione
log "user: $(whoami)"
cd "$HOME"
log "Home content:"
ls -la >> "${LogFile}"
#
################################################################################
#                                                             verify directories
PiHome="/home/pi"
Dockrepo="${PiHome}/dockrepo"
setdir "${Dockrepo}"
LogDir="${Dockrepo}/logs"
setdir "${LogDir}"
RunOnceDir="${Dockrepo}/run-once"
setdir "${RunOnceDir}"
SysDir="${Dockrepo}/sysdata"
setdir "${SysDir}"
RunOnceSysDir="${SysDir}/run-once"
setdir "${RunOnceSysDir}"
#
################################################################################
#                                                           activate run_once.sh
log "Execute run_once.sh
cd "${RunOnceDir}"
Result=$?
errorstop ${Result} "Error while ${RunOnceDir} cd"  "cd ${RunOnceDir}"
log "Working dir:"
pwd >> $LogFile
./run_once.sh
log "firstboot: run_once ended"
#
################################################################################
#                                                                 log script end
echo "`date` firstboot.sh ver. $Version ends" >> $LogFile
#
