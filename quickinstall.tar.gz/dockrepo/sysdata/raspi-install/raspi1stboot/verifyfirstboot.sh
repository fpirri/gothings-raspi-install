#!/bin/bash
#                                                                    2022-02-27
                                                                 Version="0.05"
                                                                        Debug=1
#
#  Test di verifica delle condizioni firstboot
#
#  Questo script verifica:
#  - esistenza script /boot/firstboot.sh
#  - esistenza definizione del servizio firstboot in
#      /lib/systemd/system/firstboot.service
#  - Esistenza link alla definizione sopra in:
#      /etc/systemd/system/multi-user.target.wants/firstboot.service
#  - esitenza files:
#      /home/pi/raspi1stboot/run_once.sh
#      /home/pi/raspi1stboot/run_once.tar.gz
#  - l'esistenza direttorio del dir /home/pi/raspi1stboot/ e'
#    implicitamente dimostrata sopra ...
#
#
##########################################################################
##########################################################################
#                                                           user functions
#
Red='\033[0;41;30m'
Std='\033[0;0;39m'
WorkDir="$HOME/dockrepo/raspi-install/"
LogDir="${WorkDir}log/"
LogFile="${LogDir}raspi-install.log"
#
redline(){
echo -e "${Red} $1 ${Std}"
}
#
##########################################################################
#
echo
redline  "Verify firstboot service version $Version"
#
# set 'no errors'
Error=0
#
File="/boot/firstboot.sh"
echo "Verify file ${File}"
if [[ ! -f "$File" ]]; then
  Error=$(($Error + 2));# aggiungi questo errore
  redline "Errore on file $File"
fi
#
File="/lib/systemd/system/firstboot.service"
echo "Verify file ${File}"
if [[ ! -f "$File" ]]; then
  Error=$(($Error + 4));# aggiungi questo errore
  redline "Errore on file $File"
fi
#
File="/etc/systemd/system/multi-user.target.wants/firstboot.service"
echo "Verify file ${File}"
if [[ ! -f "$File" ]]; then
  Error=$(($Error + 8));# aggiungi questo errore
  redline "Errore on file $File"
fi
#
File="/home/pi/raspi1stboot/run_once.sh"
echo "Verify file ${File}"
if [[ ! -f "$File" ]]; then
  Error=$(($Error + 16));# aggiungi questo errore
  redline "Errore on file $File"
fi
#
File="/home/pi/raspi1stboot/run_once.tar.gz"
echo "Verify file ${File}"
if [[ ! -f "$File" ]]; then
  Error=$(($Error + 32));# aggiungi questo errore
  redline "Errore on file $File"
fi
#
#  write result
#
echo "Final result: $Error"
if [ $Error -gt 0 ]
then
  redline "Error $Error while verifying the next boot conditions"
  echo "
The firstboot service will NOT run at next boot.
This means that the 'run_once' task also will NOT run."
else
  echo "Conditions OK: firstboot.service will run at next boot."
fi
exit $Error

