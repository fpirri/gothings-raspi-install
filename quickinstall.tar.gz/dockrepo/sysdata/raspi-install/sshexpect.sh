#!/usr/bin/expect
                                                              set Version "1.29"
#
set User [lindex $argv 0]
set Host [lindex $argv 1]
set Pwd [lindex $argv 2]
set LogFile [lindex $argv 3]
#
set Red "\033\[0;41;30m"
set Std "\033\[0;0;39m"
log_file "$LogFile"

send_user "Start expect script $Version- $User - $Host - $Pwd
LogFile: $LogFile\n"

set timeout  10
log_user  1
set send_slow {1 .01}

send_log  "Connecting to $Host using $User User\n"
eval spawn ssh -o UserKnownHostsFile=/dev/null -o StrictHostKeyChecking=no -o Connecttimeout=10 "$User\@$Host"
expect  {
        timeout { send_user  "timeout  while connecting to $Host\n"; exit 2 }
        "*No route to host*" { send_user  "$Host not reachable\n"; exit 3 }
        "*assword: " { send -s $Pwd\r }
        }
sleep 2
set timeout 10
send_user  "\n$Red Login successful to $Host $Std\n"
expect  {
        timeout  { send_user  "\n$Red timeout  waiting for prompt $Std\n";
                   send -s "\r";
                 }
        "pi:"   { send "ls -la\r" }
        exp_continue
        }
sleep 3
send_user  "\n$Red homedir listed $Std\n"
set timeout 10
expect  {
        timeout  { send_user  "timeout listing home dir\n"; }
        "pi:"   { send "pwd\r" }
        }
sleep 3
send_user "workdir listed\n"
set timeout 10
expect  {
        timeout  { send_user  "timeout in working dir\n"; }
        "pi:"   { send "mkdir raspi1stboot\r" }
        }
sleep 3
send_user  "\n homedir showed\n"
sleep 3
set timeout 10
expect  {
        timeout  { send_user  "\n$Red timeout creating bootdir $Std\n"; }
        "pi:"   { send_user  "\n$Red bootdir successfully created $Std\n" }
        }
send_user "$Red The raspi is prepared, let's go on ... $Std\n"

